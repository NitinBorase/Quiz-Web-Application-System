const startQuizButton = document.querySelector('button');

startQuizButton.addEventListener('click', () => {
    // Redirect to quiz page
    window.location.href = 'quiz.html';
});